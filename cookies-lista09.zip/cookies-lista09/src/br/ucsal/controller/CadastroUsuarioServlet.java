package br.ucsal.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/cadastroUsuarioServlet")
public class CadastroUsuarioServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	response.sendRedirect("cadastroUsuario.jsp");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Recuperando os parâmetros do formulário
        String nome = request.getParameter("nome");
        String email = request.getParameter("email");
        String instituicao = request.getParameter("instituicao");
        String curso = request.getParameter("curso");
        String empresa = request.getParameter("empresa");
        String cargo = request.getParameter("cargo");

        // Codificando os valores dos cookies
        nome = URLEncoder.encode(nome, "UTF-8");
        email = URLEncoder.encode(email, "UTF-8");
        instituicao = URLEncoder.encode(instituicao, "UTF-8");
        curso = URLEncoder.encode(curso, "UTF-8");
        empresa = URLEncoder.encode(empresa, "UTF-8");
        cargo = URLEncoder.encode(cargo, "UTF-8");

        // Criando cookies para armazenar as informações
        Cookie nomeCookie = new Cookie("nome", nome);
        Cookie emailCookie = new Cookie("email", email);
        Cookie instituicaoCookie = new Cookie("instituicao", instituicao);
        Cookie cursoCookie = new Cookie("curso", curso);
        Cookie empresaCookie = new Cookie("empresa", empresa);
        Cookie cargoCookie = new Cookie("cargo", cargo);

        // Definindo a duração dos cookies (opcional)
        nomeCookie.setMaxAge(60 * 60 * 24 * 7); // 1 semana
        emailCookie.setMaxAge(60 * 60 * 24 * 7); // 1 semana
        instituicaoCookie.setMaxAge(60 * 60 * 24 * 7); // 1 semana
        cursoCookie.setMaxAge(60 * 60 * 24 * 7); // 1 semana
        empresaCookie.setMaxAge(60 * 60 * 24 * 7); // 1 semana
        cargoCookie.setMaxAge(60 * 60 * 24 * 7); // 1 semana

        // Adicionando os cookies à resposta
        response.addCookie(nomeCookie);
        response.addCookie(emailCookie);
        response.addCookie(instituicaoCookie);
        response.addCookie(cursoCookie);
        response.addCookie(empresaCookie);
        response.addCookie(cargoCookie);

        // Exibindo a confirmação do cadastro
        out.println("<html><head><title>Confirmação de Cadastro</title></head><body>");
        out.println("<h1>Confirmação de Cadastro</h1>");
        out.println("<p>O cadastro foi realizado com sucesso!</p>");
        out.println("</body></html>");

        response.sendRedirect("/nascimento/recuperarCookiesServlet");
    }
}

